/* 
 * SchrodinText - Strong Protection of Sensitive Textual Content of Mobile Applications
 * File: MainActivity.java
 * Description: Test App to demonstrate SchrodinText
 *
 * Copyright (c) 2016-2019 University of California - Irvine, Irvine, USA
 * All rights reserved.
 *
 * Authors: Ardalan Amiri Sani
 *			Nicholas Wei
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions, and the following disclaimer,
 *    without modification.
 * 2. Redistributions in binary form must reproduce at minimum a disclaimer
 *    substantially similar to the "NO WARRANTY" disclaimer below
 *    ("Disclaimer") and any redistribution must be conditioned upon
 *    including a substantially similar Disclaimer requirement for further
 *    binary redistribution.
 * 3. Neither the names of the above-listed copyright holders nor the names
 *    of any contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * Alternatively, this software may be distributed under the terms of the
 * GNU General Public License ("GPL") version 2 as published by the Free
 * Software Foundation.
 *
 * NO WARRANTY
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTIBILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDERS OR CONTRIBUTORS BE LIABLE FOR SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES.
 */

package edu.uci.ardalan.schrodintextapp;

import android.app.Activity;
import android.os.Bundle;
import android.widget.SchrodinTextView;
import android.util.Log;

public class MainActivity extends Activity {

	private static final String TAG = "SchrodinTextApp";
	private boolean textShown = false;
	private SchrodinTextView textv;
	
	private void displayEncryptedText() {
        // byte can hold max of -128-127 only so for values above 127 must cast the value to byte
		// AES-ECB mode - 256-bit symmetric key is stored in entry_fast.c in OP-TEE (decrypts to "hello world")
		byte[] cipher = new byte[] {(byte) 254, 64, (byte) 194, (byte) 176, (byte) 170, 108, (byte) 236, (byte) 234, 
									75, (byte) 245, (byte) 144, 13, 26, (byte) 187, 41, (byte) 130};

		textv.setCiphertext(cipher, 16, 11, 1);
		textShown = true;
	}
	
	private void hideEncryptedText() {
		if (textShown) {
			textv.clearCiphertext();
			textShown = false;
		}
	}

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "SchrodinTextApp Start");
		setContentView(R.layout.activity_main);
		textv = (SchrodinTextView) findViewById(R.id.TextView1);
        displayEncryptedText();
    }
    
    // Called when window gains or loses focus (i.e. moved to background,
    // moved from background to foreground, notification bar pulled down, etc).
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
    	super.onWindowFocusChanged(hasFocus);
    	if (hasFocus) {		// window gains focus
    		if (!textShown)
    			displayEncryptedText();
    	}
    	else {		// window loses focus
    		hideEncryptedText();
    	}
    }
    
    // Called when app is cleared from memory
    @Override
    protected void onDestroy() {
    	Log.d(TAG, "SchrodinTextApp Stop");
    	super.onDestroy();
		hideEncryptedText();
    }
}
