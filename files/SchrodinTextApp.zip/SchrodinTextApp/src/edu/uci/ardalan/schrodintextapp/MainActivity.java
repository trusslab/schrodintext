package edu.uci.ardalan.schrodintextapp;

import android.app.Activity;
import android.os.Bundle;
import android.widget.SchrodinTextView;
import android.util.Log;

public class MainActivity extends Activity {

	private static final String TAG = "SchrodinTextApp";
	private boolean textShown = false;
	private SchrodinTextView textv;
	
	private void displayEncryptedText() {
        // byte can hold max of -128-127 only so for values above 127 must cast the value to byte
		// AES-ECB mode - 256-bit symmetric key is stored in entry_fast.c in OP-TEE (decrypts to "hello world")
		byte[] cipher = new byte[] {(byte) 254, 64, (byte) 194, (byte) 176, (byte) 170, 108, (byte) 236, (byte) 234, 
									75, (byte) 245, (byte) 144, 13, 26, (byte) 187, 41, (byte) 130};

		textv.setCiphertext(cipher, 16, 11, 1);
		textShown = true;
	}
	
	private void hideEncryptedText() {
		if (textShown) {
			textv.clearCiphertext();
			textShown = false;
		}
	}

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "SchrodinTextApp Start");
        Log.d(TAG, "System Wall Clock Time (ms): " + System.currentTimeMillis());
		setContentView(R.layout.activity_main);
		textv = (SchrodinTextView) findViewById(R.id.TextView1);
        displayEncryptedText();
    }
    
    // Called when window gains or loses focus (i.e. moved to background,
    // moved from background to foreground, notification bar pulled down, etc).
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
    	super.onWindowFocusChanged(hasFocus);
    	if (hasFocus) {		// window gains focus
    		if (!textShown)
    			displayEncryptedText();
    	}
    	else {		// window loses focus
    		hideEncryptedText();
    	}
    }
    
    // Called when app is cleared from memory
    @Override
    protected void onDestroy() {
    	Log.d(TAG, "SchrodinTextApp Stop");
    	super.onDestroy();
		hideEncryptedText();
    }
}
