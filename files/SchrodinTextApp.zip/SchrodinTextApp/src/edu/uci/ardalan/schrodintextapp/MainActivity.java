package edu.uci.ardalan.schrodintextapp;

import android.app.Activity;
import android.os.Bundle;
import android.widget.SchrodinTextView;
import android.util.Log;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // byte can hold max of -128-127 only (two's complement)
		byte[] cipher = new byte[] {(byte) 193,(byte) 208,77,(byte) 182,120,26,108,89,119,(byte) 237,(byte) 134,(byte) 157,79,47,(byte) 251,62,88,(byte) 160,(byte) 167,(byte) 215,118,116,0,(byte) 202,86,76,99,111,(byte) 153,126,(byte) 225,91};

		Log.d("SchrodinTextApp", "[1]");
		setContentView(R.layout.activity_main);
		SchrodinTextView textv = (SchrodinTextView) findViewById(R.id.TextView1);
		textv.setCiphertext(cipher, 32, 20, 1);
		Log.d("SchrodinTextApp", "[exit]");
    }
}
